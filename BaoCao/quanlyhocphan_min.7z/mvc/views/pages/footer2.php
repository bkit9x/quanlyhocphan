</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?= DOMAIN ?>public/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= DOMAIN ?>public/bootstrap/dist/js/bootstrap.min.js"></script>
</body>

</html>