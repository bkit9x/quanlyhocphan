<?php
define("DOMAIN","http://quanlyhocphan.com/");
