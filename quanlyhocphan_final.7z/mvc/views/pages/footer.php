</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.18
    </div>
    <strong>Copyright &copy; 2021 AdminLTE.</strong> All rights
    reserved.
</footer>
<!-- ./wrapper -->

<!-- Bootstrap 3.3.7 -->
<script src="<?= DOMAIN ?>public/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- adminlte -->
<script src="<?= DOMAIN ?>public/dist/js/adminlte.min.js"></script>
</body>

</html>